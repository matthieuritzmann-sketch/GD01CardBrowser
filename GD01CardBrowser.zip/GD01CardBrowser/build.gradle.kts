// vide
